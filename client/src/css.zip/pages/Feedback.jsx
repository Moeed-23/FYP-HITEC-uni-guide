import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../css/feedback.css";
import API from "../api";
import "@fortawesome/fontawesome-free/css/all.min.css";

const Feedback = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    rating: "5",
    comments: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/api/feedback`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const result = await response.json();
        console.log("Feedback submitted successfully:", result);
        alert("Thank you for your feedback!");
        setFormData({ name: "", email: "", rating: "5", comments: "" });
      } else {
        const errorData = await response.json();
        console.error("Feedback submission failed:", errorData);
        alert("Failed to submit feedback. Please try again.");
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
      alert("An error occurred. Please try again later.");
    }
  };

  return (
    <>
      <title>HITEC | UNIGUIDE | FEEDBACK</title>
      <div className="feedback-container">
        <header className="landing-header">
          <nav>
            <Link to="/homepage">Home</Link>
            <Link to="/chatbot">Chat</Link>
            <Link to="/admissions">Admissions</Link>
            <Link to="/events">Events</Link>
            <Link to="/tour">Tour</Link>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/alumni">Alumni</Link>
            <Link to="/industry-integration">Industry Integration</Link>
            <Link to="/feedback">Feedback</Link>
          </nav>
        </header>

        <section className="feedback-intro">
          <h1>Feedback</h1>
          <p>
            We value your input! Share your thoughts and help us improve
            UniGuide Chatbot.
          </p>
        </section>

        <section className="feedback-form-container">
          <h2>Submit Your Feedback</h2>
          <form onSubmit={handleSubmit} className="feedback-form">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder="Enter your name"
              value={formData.name}
              onChange={handleChange}
              required
            />

            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <label htmlFor="rating">Rate Your Experience:</label>
            <select
              id="rating"
              name="rating"
              value={formData.rating}
              onChange={handleChange}
            >
              <option value="5">Excellent</option>
              <option value="4">Good</option>
              <option value="3">Average</option>
              <option value="2">Poor</option>
              <option value="1">Very Poor</option>
            </select>

            <label htmlFor="comments">Comments:</label>
            <textarea
              id="comments"
              name="comments"
              rows="5"
              placeholder="Share your thoughts..."
              value={formData.comments}
              onChange={handleChange}
              required
            />

            <button type="submit">Submit Feedback</button>
          </form>
        </section>

        <footer className="feedback-footer">
          <p>&copy; 2025 HITEC University. All rights reserved.</p>
          <div className="feedback-social-icons">
            <a href="https://www.facebook.com/hitecuni/">
              <i className="fab fa-facebook-f"></i>
            </a>
            
            <a href="https://www.instagram.com/hitecuni/?hl=en">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all">
              <i className="fab fa-linkedin-in"></i>
            </a>
          </div>
        </footer>
      </div>
    </>
  );
};

export default Feedback;
