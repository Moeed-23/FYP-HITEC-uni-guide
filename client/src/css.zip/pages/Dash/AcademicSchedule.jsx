import { useAuth } from "../../context/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../css/dash/academicschedule.css";

const AcademicSchedule = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [schedule, setSchedule] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSchedule = async () => {
      const token = localStorage.getItem("token");
      if (!user?._id || !token) {
        navigate("/login");
        return;
      }
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const response = await axios.get(
          `${apiUrl}/api/users/${user._id}/academic-schedule`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setSchedule(response.data);
      } catch (err) {
        console.error("Error fetching academic schedule:", err);
        setError("Failed to load academic schedule. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchSchedule();
  }, [user, navigate]);

  if (loading) return <div>Loading academic schedule...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
    <title>HITEC | UNIGUIDE | DASHBOARD | ACADEMIC_SCHEDULE</title>
    <div>
      <h2>Your Academic Schedule</h2>
      {schedule && schedule.length > 0 ? (
        schedule.map((item) => (
          <div key={item._id}>
            <h4>{item.courseName}</h4>
            <p>
              {new Date(item.date).toLocaleDateString()} at {item.time}
            </p>
          </div>
        ))
      ) : (
        <p>No academic schedule found.</p>
      )}
    </div>
    </>
  );
};

export default AcademicSchedule;
