// import { useAuth } from "../../context/AuthContext";
// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const Profile = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();
//   const [profileData, setProfileData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   useEffect(() => {
//     const fetchProfile = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setProfileData(response.data);
//       } catch (err) {
//         console.error("Error fetching profile:", err);
//         setError("Failed to load profile. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchProfile();
//   }, [user, navigate]);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem("token");
//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       const response = await axios.put(
//         `${apiUrl}/api/users/${user._id}`,
//         profileData,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       setSuccess("Profile updated successfully.");
//     } catch (err) {
//       console.error("Error updating profile:", err);
//       setError("Failed to update profile.");
//     }
//   };

//   if (loading) return <div>Loading profile...</div>;
//   if (error) return <div>{error}</div>;

//   return (
//     <div>
//       <h2>My Profile</h2>
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>Name: </label>
//           <input
//             type="text"
//             value={profileData.name || ""}
//             onChange={(e) =>
//               setProfileData({ ...profileData, name: e.target.value })
//             }
//           />
//         </div>
//         <div>
//           <label>Email: </label>
//           <input
//             type="email"
//             value={profileData.email || ""}
//             onChange={(e) =>
//               setProfileData({ ...profileData, email: e.target.value })
//             }
//           />
//         </div>
//         <button type="submit">Update Profile</button>
//       </form>
//     </div>
//   );
// };

// export default Profile;


//////////////////////////////////////////////


// import { useAuth } from "../../context/AuthContext";
// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";

// const Profile = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();
//   // Initialize with empty fields to avoid undefined errors
//   const [profileData, setProfileData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//   });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   useEffect(() => {
//     const fetchProfile = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         setProfileData(response.data);
//       } catch (err) {
//         console.error("Error fetching profile:", err);
//         setError("Failed to load profile. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchProfile();
//   }, [user, navigate]);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem("token");
//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       await axios.put(`${apiUrl}/api/users/${user._id}`, profileData, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setSuccess("Profile updated successfully.");
//     } catch (err) {
//       console.error("Error updating profile:", err);
//       setError("Failed to update profile.");
//     }
//   };

//   if (loading) return <div>Loading profile...</div>;
//   if (error) return <div>{error}</div>;

//   return (
//     <>
//     <title>HITEC | UNIGUIDE | DASHBOARD | PROFILE</title>
//     <div>
//       <h2>My Profile</h2>
//       {success && <p style={{ color: "green" }}>{success}</p>}
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>First Name: </label>
//           <input
//             type="text"
//             value={profileData.firstName || ""}
//             onChange={(e) =>
//               setProfileData({ ...profileData, firstName: e.target.value })
//             }
//           />
//         </div>
//         <div>
//           <label>Last Name: </label>
//           <input
//             type="text"
//             value={profileData.lastName || ""}
//             onChange={(e) =>
//               setProfileData({ ...profileData, lastName: e.target.value })
//             }
//           />
//         </div>
//         <div>
//           <label>Email: </label>
//           <input
//             type="email"
//             value={profileData.email || ""}
//             onChange={(e) =>
//               setProfileData({ ...profileData, email: e.target.value })
//             }
//           />
//         </div>
//         <button type="submit">Update Profile</button>
//       </form>
//     </div>
//     </>
//   );
// };

// export default Profile;



////////////////////////////////////

// import { useAuth } from "../../context/AuthContext";
// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import "../../css/dash/profile.css";

// const Profile = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   // State to hold profile details
//   const [profileData, setProfileData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//     phone: "",
//     password: ""
//   });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");
//   const [editMode, setEditMode] = useState(false);

//   // Fetch user details on component mount
//   useEffect(() => {
//     const fetchProfile = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         // Set the profile data; note that for security reasons password is not fetched.
//         setProfileData({
//           firstName: response.data.firstName || "",
//           lastName: response.data.lastName || "",
//           email: response.data.email || "",
//           phone: response.data.phone || "",
//           password: "" // kept empty since it is not retrieved from the backend
//         });
//       } catch (err) {
//         console.error("Error fetching profile:", err);
//         setError("Failed to load profile. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchProfile();
//   }, [user, navigate]);

//   // Handle form submission in edit mode
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem("token");
//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       // Update the user details (email is not being updated)
//       await axios.put(`${apiUrl}/api/users/${user._id}`, profileData, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setSuccess("Profile updated successfully.");
//       // Return to read-only view after updating
//       setEditMode(false);
//     } catch (err) {
//       console.error("Error updating profile:", err);
//       setError("Failed to update profile.");
//     }
//   };

//   // Toggle to edit mode
//   const handleEdit = () => {
//     setEditMode(true);
//     // Clear any previous messages
//     setError("");
//     setSuccess("");
//   };

//   // Cancel edit and go back to display mode
//   const handleCancel = () => {
//     setEditMode(false);
//     // Optionally, you could re-fetch the original details if the user cancels editing
//   };

//   if (loading) return <div>Loading profile...</div>;
//   if (error && !editMode) return <div>{error}</div>;

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD | PROFILE</title>
//       <div className="user-profile">
//         {!editMode ? (
//           // Read-only view of profile details
//           <>
//             <h2>My Profile</h2>
//             <div>
//               <strong>First Name:</strong> {profileData.firstName}
//             </div>
//             <div>
//               <strong>Last Name:</strong> {profileData.lastName}
//             </div>
//             <div>
//               <strong>Email:</strong> {profileData.email}
//             </div>
//             <div>
//               <strong>Phone Number:</strong> {profileData.phone}
//             </div>
//             <div>
//               <strong>Password:</strong> {profileData.password ? "********" : "Not Set"}
//             </div>
//             <button type="button" onClick={handleEdit}>Edit personal details</button>
//           </>
//         ) : (
//           // Edit mode: allow updating first name, last name, phone number, and password.
//           <div>
//             <h2>Updata Personal Information</h2>
//             {success && <p style={{ color: "green" }}>{success}</p>}
//             {error && <p style={{ color: "red" }}>{error}</p>}
//             <form onSubmit={handleSubmit}>
//               <div>
//                 <label>First Name: </label>
//                 <input
//                   type="text"
//                   value={profileData.firstName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, firstName: e.target.value })
//                   }
//                   placeholder="Enter first name"
//                 />
//               </div>
//               <div>
//                 <label>Last Name: </label>
//                 <input
//                   type="text"
//                   value={profileData.lastName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, lastName: e.target.value })
//                   }
//                   placeholder="Enter last name"
//                 />
//               </div>
//               <div>
//                 <label>Phone Number: </label>
//                 <input
//                   type="tel"
//                   value={profileData.phone}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, phone: e.target.value })
//                   }
//                   placeholder="Enter phone number"
//                 />
//               </div>
//               <div>
//                 <label>Password: </label>
//                 <input
//                   type="password"
//                   value={profileData.password}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, password: e.target.value })
//                   }
//                   placeholder="Enter new password (optional)"
//                 />
//               </div>
//               <div>
//                 <label>Email: </label>
//                 {/* Email is fixed and not editable */}
//                 <span>{profileData.email}</span>
//               </div>
//               <button type="submit">Update Profile</button>
//               <button type="button" onClick={handleCancel}>
//                 Cancel
//               </button>
//             </form>
//           </div>
//         )}
//       </div>
//     </>
//   );
// };

// export default Profile;



//////////////////////////////////////////////////////////////////////////////////////////////



// import { useAuth } from "../../context/AuthContext";
// import { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import "../../css/dash/profile.css";

// const Profile = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   // State to hold profile details
//   const [profileData, setProfileData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//     phone: "",
//     password: ""
//   });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");
//   const [editMode, setEditMode] = useState(false);

//   // Fetch user details on component mount
//   useEffect(() => {
//     const fetchProfile = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         // Set the profile data; password is intentionally kept empty
//         setProfileData({
//           firstName: response.data.firstName || "",
//           lastName: response.data.lastName || "",
//           email: response.data.email || "",
//           phone: response.data.phone || "",
//           password: ""
//         });
//       } catch (err) {
//         console.error("Error fetching profile:", err);
//         setError("Failed to load profile. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchProfile();
//   }, [user, navigate]);

//   // Handle form submission in edit mode to update only non-empty fields
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem("token");

//     // Build an update payload with only non-empty fields.
//     // Fields left empty will be excluded so they remain unchanged.
//     const updatePayload = {};
//     if (profileData.firstName.trim() !== "") {
//       updatePayload.firstName = profileData.firstName;
//     }
//     if (profileData.lastName.trim() !== "") {
//       updatePayload.lastName = profileData.lastName;
//     }
//     if (profileData.phone.trim() !== "") {
//       updatePayload.phone = profileData.phone;
//     }
//     // Only update password if a new one is provided.
//     if (profileData.password.trim() !== "") {
//       updatePayload.password = profileData.password;
//     }
//     // The email field is fixed; it will not be updated.

//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       await axios.put(`${apiUrl}/api/users/${user._id}`, updatePayload, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setSuccess("Profile updated successfully.");
//       // Optionally, you can update the state here if needed before leaving edit mode.
//       setEditMode(false);
//     } catch (err) {
//       console.error("Error updating profile:", err);
//       setError("Failed to update profile.");
//     }
//   };

//   // Toggle to edit mode
//   const handleEdit = () => {
//     setEditMode(true);
//     // Clear any previous messages
//     setError("");
//     setSuccess("");
//   };

//   // Cancel edit and go back to display mode
//   const handleCancel = () => {
//     setEditMode(false);
//     // Optionally, re-fetch original data if needed
//   };

//   if (loading) return <div>Loading profile...</div>;
//   if (error && !editMode) return <div>{error}</div>;

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD | PROFILE</title>
//       <div className="user-profile">
//         {!editMode ? (
//           // Read-only view of profile details
//           <>
//             <h2>My Profile</h2>
//             <div>
//               <strong>First Name:</strong> {profileData.firstName}
//             </div>
//             <div>
//               <strong>Last Name:</strong> {profileData.lastName}
//             </div>
//             <div>
//               <strong>Email:</strong> {profileData.email}
//             </div>
//             <div>
//               <strong>Phone Number:</strong> {profileData.phone}
//             </div>
//             <div>
//               <strong>Password:</strong> {profileData.password ? "********" : "Not Set"}
//             </div>
//             <button type="button" onClick={handleEdit}>Edit personal details</button>
//           </>
//         ) : (
//           // Edit mode: allow updating specific fields.
//           <div>
//             <h2>Update Personal Information</h2>
//             {success && <p style={{ color: "green" }}>{success}</p>}
//             {error && <p style={{ color: "red" }}>{error}</p>}
//             <form onSubmit={handleSubmit}>
//               <div>
//                 <label>First Name: </label>
//                 <input
//                   type="text"
//                   value={profileData.firstName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, firstName: e.target.value })
//                   }
//                   placeholder="Enter first name"
//                 />
//               </div>
//               <div>
//                 <label>Last Name: </label>
//                 <input
//                   type="text"
//                   value={profileData.lastName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, lastName: e.target.value })
//                   }
//                   placeholder="Enter last name"
//                 />
//               </div>
//               <div>
//                 <label>Phone Number: </label>
//                 <input
//                   type="tel"
//                   value={profileData.phone}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, phone: e.target.value })
//                   }
//                   placeholder="Enter phone number"
//                 />
//               </div>
//               <div>
//                 <label>Password: </label>
//                 <input
//                   type="password"
//                   value={profileData.password}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, password: e.target.value })
//                   }
//                   placeholder="Enter new password (optional)"
//                 />
//               </div>
//               <div>
//                 <label>Email: </label>
//                 {/* Email is fixed and not editable */}
//                 <span>{profileData.email}</span>
//               </div>
//               <div className="button-group">
//                 <button type="submit">Update Profile</button>
//                 <button type="button" onClick={handleCancel}>
//                   Cancel
//                 </button>
//               </div>
//             </form>
//           </div>
//         )}
//       </div>
//     </>
//   );
// };

// export default Profile;







////////////////////////////////////////////
//////////////////////////////
/////////4/13/2025

// import { useAuth } from "../../context/AuthContext";
// import { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import axios from "axios";
// import { 
//   AiFillEye, 
//   AiFillEyeInvisible, 
//   AiOutlineArrowLeft 
// } from "react-icons/ai";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../../css/dash/profile.css";

// const Profile = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   // State to hold profile details
//   const [profileData, setProfileData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//     phone: "",
//     password: "",
//   });
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");
//   const [editMode, setEditMode] = useState(false);

//   // Local state to manage password visibility
//   const [showPassword, setShowPassword] = useState(false);

//   // Toggle password visibility
//   const togglePasswordVisibility = () => {
//     setShowPassword((prev) => !prev);
//   };

//   // Fetch user details on component mount
//   useEffect(() => {
//     const fetchProfile = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         // NOTE: Typically, the server won't return the plain-text password.
//         // This example is for demonstration purposes only.
//         setProfileData({
//           firstName: response.data.firstName || "",
//           lastName: response.data.lastName || "",
//           email: response.data.email || "",
//           phone: response.data.phone || "",
//           password: response.data.password || "",
//         });
//       } catch (err) {
//         console.error("Error fetching profile:", err);
//         setError("Failed to load profile. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchProfile();
//   }, [user, navigate]);

//   // Handle form submission in edit mode
//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const token = localStorage.getItem("token");

//     // Build an update payload with only non-empty fields.
//     const updatePayload = {};
//     if (profileData.firstName.trim() !== "") {
//       updatePayload.firstName = profileData.firstName;
//     }
//     if (profileData.lastName.trim() !== "") {
//       updatePayload.lastName = profileData.lastName;
//     }
//     if (profileData.phone.trim() !== "") {
//       updatePayload.phone = profileData.phone;
//     }
//     // Only update password if a new value is provided.
//     if (profileData.password.trim() !== "") {
//       updatePayload.password = profileData.password;
//     }

//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       await axios.put(`${apiUrl}/api/users/${user._id}`, updatePayload, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setSuccess("Profile updated successfully.");
//       setEditMode(false);
//     } catch (err) {
//       console.error("Error updating profile:", err);
//       setError("Failed to update profile.");
//     }
//   };

//   // Toggle to edit mode
//   const handleEdit = () => {
//     setEditMode(true);
//     setError("");
//     setSuccess("");
//   };

//   // Cancel edit and return to read-only view
//   const handleCancel = () => {
//     setEditMode(false);
//   };

//   if (loading) return <div>Loading profile...</div>;
//   if (error && !editMode) return <div>{error}</div>;

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD | PROFILE</title>

//       <header className="landing-header">
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <div className="user-profile">
//         {!editMode ? (
//           // ---------- Read-only view of profile details ----------
//           <>
//             {/* Back arrow button */}
//             <div className="back-arrow" onClick={() => navigate("/dashboard")}>
//               <AiOutlineArrowLeft size={30} />
//             </div>
//             <h2>My Profile</h2>
//             <div className="profile-details">
//             <div>
//               <strong>First Name:</strong> {profileData.firstName}
//             </div>
//             <div>
//               <strong>Last Name:</strong> {profileData.lastName}
//             </div>
//             <div>
//               <strong>Email:</strong> {profileData.email}
//             </div>
//             <div>
//               <strong>Phone Number:</strong> {profileData.phone}
//             </div>
//             </div>
//             <button
//               type="button"
//               onClick={handleEdit}
//               className="edit-btn"
//               style={{ marginTop: "1em" }}
//             >
//               Edit personal details
//             </button>
//           </>
//         ) : (
//           // ---------- Edit mode: allow updating specific fields ----------
//           <div>
//             <div className="back-arrow" onClick={handleCancel}>
//               <AiOutlineArrowLeft size={30} />
//             </div>

//             <h2>Update Personal Information</h2>
//             {success && <p style={{ color: "green" }}>{success}</p>}
//             {error && <p style={{ color: "red" }}>{error}</p>}
//             <form onSubmit={handleSubmit}>
//               <div className="form-group">
//                 <label>First Name:</label>
//                 <input
//                   type="text"
//                   value={profileData.firstName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, firstName: e.target.value })
//                   }
//                   placeholder="Enter first name"
//                 />
//               </div>
//               <div className="form-group">
//                 <label>Last Name:</label>
//                 <input
//                   type="text"
//                   value={profileData.lastName}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, lastName: e.target.value })
//                   }
//                   placeholder="Enter last name"
//                 />
//               </div>
//               <div className="form-group">
//                 <label>Phone Number:</label>
//                 <input
//                   type="tel"
//                   value={profileData.phone}
//                   onChange={(e) =>
//                     setProfileData({ ...profileData, phone: e.target.value })
//                   }
//                   placeholder="Enter phone number"
//                 />
//               </div>
//               <div className="form-group password-group">
//                 <label>Password:</label>
//                 <div className="password-wrapper">
//                   <input
//                     type={showPassword ? "text" : "password"}
//                     value={profileData.password}
//                     onChange={(e) =>
//                       setProfileData({ ...profileData, password: e.target.value })
//                     }
//                     placeholder="Enter new password (optional)"
//                   />
//                   <button type="button" onClick={togglePasswordVisibility} className="toggle-btn">
//                     {showPassword ? <AiFillEyeInvisible /> : <AiFillEye />}
//                   </button>
//                 </div>
//               </div>
//               <div className="form-group">
//                 <label>Email:</label>
//                 <span>{profileData.email}</span>
//               </div>
//               <div className="button-group">
//                 <button type="submit" className="update-btn" style={{ marginRight: "10px" }}>
//                   Update Profile
//                 </button>
//                 <button type="button" onClick={handleCancel} className="cancel-btn">
//                   Cancel
//                 </button>
//               </div>
//             </form>
//           </div>
//         )}
//       </div>

//       <footer className="landing-footer">
//         <div className="footer-content">
//           <p>&copy; 2025 HITEC University. All rights reserved.</p>
//           <div className="social-icons">
//             <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//               <i className="fab fa-facebook-f"></i>
//             </a>
//             <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
//               <i className="fab fa-instagram"></i>
//             </a>
//             <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all" aria-label="LinkedIn">
//               <i className="fab fa-linkedin-in"></i>
//             </a>
//           </div>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Profile;


///////////////////
//////////////////////
/////////////////////////

import { useAuth } from "../../context/AuthContext";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { 
  AiFillEye, 
  AiFillEyeInvisible, 
  AiOutlineArrowLeft 
} from "react-icons/ai";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "../../css/dash/profile.css";

const Profile = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // State to hold profile details
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [editMode, setEditMode] = useState(false);

  // Local state to manage password visibility
  const [showPassword, setShowPassword] = useState(false);

  // Toggle password visibility
  const togglePasswordVisibility = () => {
    setShowPassword((prev) => !prev);
  };

  // Fetch user details on component mount
  useEffect(() => {
    const fetchProfile = async () => {
      const token = localStorage.getItem("token");
      if (!user?._id || !token) {
        navigate("/login");
        return;
      }
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        // NOTE: Typically, the server won't return the plain-text password.
        // This example is for demonstration purposes only.
        setProfileData({
          firstName: response.data.firstName || "",
          lastName: response.data.lastName || "",
          email: response.data.email || "",
          phone: response.data.phone || "",
          password: response.data.password || "",
        });
      } catch (err) {
        console.error("Error fetching profile:", err);
        setError("Failed to load profile. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [user, navigate]);

  // Handle form submission in edit mode
  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    // Build an update payload.
    // For first name, last name, and password, update only if non-empty.
    // For phone number, always include its current value (even if empty).
    const updatePayload = {};
    if (profileData.firstName.trim() !== "") {
      updatePayload.firstName = profileData.firstName;
    }
    if (profileData.lastName.trim() !== "") {
      updatePayload.lastName = profileData.lastName;
    }
    // Always update phone number—if cleared it will be an empty string.
    updatePayload.phone = profileData.phone;
    // Only update password if a new value is provided.
    if (profileData.password.trim() !== "") {
      updatePayload.password = profileData.password;
    }

    try {
      const apiUrl = import.meta.env.VITE_API_URL;
      await axios.put(`${apiUrl}/api/users/${user._id}`, updatePayload, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSuccess("Profile updated successfully.");
      setEditMode(false);
    } catch (err) {
      console.error("Error updating profile:", err);
      setError("Failed to update profile.");
    }
  };

  // Toggle to edit mode
  const handleEdit = () => {
    setEditMode(true);
    setError("");
    setSuccess("");
  };

  // Cancel edit and return to read-only view
  const handleCancel = () => {
    setEditMode(false);
  };

  if (loading) return <div>Loading profile...</div>;
  if (error && !editMode) return <div>{error}</div>;

  return (
    <>
      <title>HITEC | UNIGUIDE | DASHBOARD | PROFILE</title>

      <header className="landing-header">
        <nav>
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <div className="profile-container">
        {!editMode ? (
          // ---------- Read-only view ----------
          <>
            <div className="profile-back-arrow" onClick={() => navigate("/dashboard")}>
              <AiOutlineArrowLeft size={30} />
            </div>
            <h2 className="profile-title">My Profile</h2>
            <div className="profile-details">
              <div>
                <strong>First Name:</strong> {profileData.firstName}
              </div>
              <div>
                <strong>Last Name:</strong> {profileData.lastName}
              </div>
              <div>
                <strong>Email:</strong> {profileData.email}
              </div>
              <div>
                <strong>Phone Number:</strong> {profileData.phone}
              </div>
            </div>
            <button
              type="button"
              onClick={handleEdit}
              className="profile-edit-btn center-button"
              style={{ marginTop: "1em" }}
            >
              Edit personal details
            </button>
          </>
        ) : (
          // ---------- Edit mode ----------
          <div>
            <div className="profile-back-arrow" onClick={handleCancel}>
              <AiOutlineArrowLeft size={30} />
            </div>
            <h2 className="profile-title">Update Personal Information</h2>
            {success && <p style={{ color: "green" }}>{success}</p>}
            {error && <p style={{ color: "red" }}>{error}</p>}
            <form onSubmit={handleSubmit} className="profile-form">
              <div className="profile-form-group">
                <label>First Name:</label>
                <input
                  type="text"
                  value={profileData.firstName}
                  onChange={(e) =>
                    setProfileData({ ...profileData, firstName: e.target.value })
                  }
                  placeholder="Enter first name"
                />
              </div>
              <div className="profile-form-group">
                <label>Last Name:</label>
                <input
                  type="text"
                  value={profileData.lastName}
                  onChange={(e) =>
                    setProfileData({ ...profileData, lastName: e.target.value })
                  }
                  placeholder="Enter last name"
                />
              </div>
              <div className="profile-form-group">
                <label>Phone Number:</label>
                <input
                  type="tel"
                  value={profileData.phone}
                  onChange={(e) =>
                    setProfileData({ ...profileData, phone: e.target.value })
                  }
                  placeholder="Enter phone number"
                />
              </div>
              <div className="profile-form-group profile-password-group">
                <label>Password:</label>
                <div className="profile-password-wrapper">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={profileData.password}
                    onChange={(e) =>
                      setProfileData({ ...profileData, password: e.target.value })
                    }
                    placeholder="Enter new password (optional)"
                  />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="profile-toggle-btn"
                  >
                    {showPassword ? <AiFillEyeInvisible /> : <AiFillEye />}
                  </button>
                </div>
              </div>
              <div className="profile-form-group">
                <label>Email:</label>
                <span>{profileData.email}</span>
              </div>
              <div className="profile-button-group">
                <button type="submit" className="profile-update-btn" style={{ marginRight: "10px" }}>
                  Update Profile
                </button>
                <button type="button" onClick={handleCancel} className="profile-cancel-btn">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      <footer className="landing-footer">
        <div className="footer-content">
          <p>&copy; 2025 HITEC University. All rights reserved.</p>
          <div className="social-icons">
            <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all" aria-label="LinkedIn">
              <i className="fab fa-linkedin-in"></i>
            </a>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Profile;
