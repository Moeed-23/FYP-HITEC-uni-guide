import { useAuth } from "../../context/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../css/dash/notifications.css";

const Notifications = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchNotifications = async () => {
      const token = localStorage.getItem("token");
      if (!user?._id || !token) {
        navigate("/login");
        return;
      }
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const response = await axios.get(
          `${apiUrl}/api/users/${user._id}/notifications`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setNotifications(response.data);
      } catch (err) {
        console.error("Error fetching notifications:", err);
        setError("Failed to load notifications. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchNotifications();
  }, [user, navigate]);

  if (loading) return <div>Loading notifications...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
      <title>HITEC | UNIGUIDE | DASHBOARD | NOTIFICATIONS</title>
   
    <div>
      <h2>Your Notifications</h2>
      {notifications && notifications.length > 0 ? (
        notifications.map((n) => (
          <div key={n._id}>
            <p>{n.message}</p>
          </div>
        ))
      ) : (
        <p>No notifications found.</p>
      )}
    </div>
    </>
  );
};

export default Notifications;
