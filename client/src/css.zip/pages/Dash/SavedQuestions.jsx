import { useAuth } from "../../context/AuthContext";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../../css/dash/savedquestions.css";

const SavedQuestions = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchSavedQuestions = async () => {
      const token = localStorage.getItem("token");
      if (!user?._id || !token) {
        navigate("/login");
        return;
      }
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const response = await axios.get(
          `${apiUrl}/api/users/${user._id}/saved-questions`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setQuestions(response.data);
      } catch (err) {
        console.error("Error fetching saved questions:", err);
        setError("Failed to load saved questions. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchSavedQuestions();
  }, [user, navigate]);

  if (loading) return <div>Loading your saved questions...</div>;
  if (error) return <div>{error}</div>;

  return (
    <>
    <title>HITEC | UNIGUIDE | DASHBOARD | SAVED_QUESTIONS</title>
    <div>
      <h2>Your Saved Questions</h2>
      {questions && questions.length > 0 ? (
        questions.map((q) => (
          <div key={q._id}>
            <h4>{q.title}</h4>
            <p>{q.body}</p>
          </div>
        ))
      ) : (
        <p>No saved questions found.</p>
      )}
    </div>
    </>
  );
};

export default SavedQuestions;
