import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../css/tour.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

const Tour = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const locations = [
    {
      title: "Main Campus",
      description: "Central hub of academics with main departments and admin blocks.",
      iframe: "https://www.google.com/maps/embed?...MainCampusURL",
      subBlocks: [
        {
          title: "Israr Block",
          description: "Engineering block housing multiple academic departments.",
          iframe: "https://www.google.com/maps/embed?...NusratBlockURL",
        },
        {
          title: "Rumi Block",
          description: "Block dedicated to humanities and social sciences.",
          iframe: "https://www.google.com/maps/embed?...RumiBlockURL",
        },
        {
          title: "Sir Syed Block",
          description: "Center for innovation and entrepreneurship studies.",
          iframe: "https://www.google.com/maps/embed?...SirSyedBlockURL",
        },
        {
          title: "Secretariat Block",
          description: "Core administrative center of the university.",
          iframe: "https://www.google.com/maps/embed?...SecretariatBlockURL",
        },
      ]
    },
    {
      title: "Library",
      description: "Navigate to the heart of knowledge with a detailed map of the library.",
      iframe: "https://www.google.com/maps/embed?...LibraryURL"
    },
    {
      title: "Sports Complex",
      description: "Find your way to recreational and sporting activities.",
       iframe: "https://www.google.com/maps/embed?...SoprtsComplexURL"
    },
    {
      title: "Jinnah Hostel",
      description: "Residential facility for students with all basic amenities.",
      iframe: "https://www.google.com/maps/embed?...JinnahHostelURL"
    },
    {
      title: "Secretariat",
      description: "Administrative office for faculty and student affairs.",
      iframe: "https://www.google.com/maps/embed?...SecretariatURL"
    },
    {
      title: "Entry Gate",
      description: "Main entrance to the university campus.",
      iframe: "https://www.google.com/maps/embed?...EntryGateURL"
    },
    {
      title: "Exit Gate",
      description: "Exit point for university traffic.",
      iframe: "https://www.google.com/maps/embed?...ExitGateURL"
    },
    {
      title: "Mosque",
      description: "Prayer area located within the campus for spiritual well-being.",
      iframe: "https://www.google.com/maps/embed?...MosqueURL"
    }
  ];

  // Flatten locations and subBlocks into one searchable list
  const getAllCards = () => {
    let all = [];
    locations.forEach((loc) => {
      all.push(loc);
      if (loc.subBlocks) {
        loc.subBlocks.forEach(sub => all.push({ ...sub, parent: loc.title }));
      }
    });
    return all;
  };

  // Filter locations and sub-blocks based on search term
  const filteredLocations = getAllCards().filter(location => {
    const searchLower = searchTerm.trim().toLowerCase();
    return (
      location.title.toLowerCase().includes(searchLower) ||
      location.description.toLowerCase().includes(searchLower)
    );
  });

  return (
    <>
    
      <title>HITEC | UNIGUIDE | TOUR</title>
      <header className="landing-header">
        <nav>
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <section className="tourIntro">
        <h1>Campus Tour</h1>
        <p>Navigate your way through the campus with our interactive maps and guides.</p>
      </section>

      <section className="tourSearchBar">
        <input
          type="text"
          placeholder="Search for a campus location..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button disabled><i className="fas fa-search"></i></button>
      </section>

      <section className="mapSection">
        {filteredLocations.length > 0 ? (
          filteredLocations.map((location, index) => (
            <div className="mapCard" key={index}>
              <iframe
                src={location.iframe}
                allowFullScreen
                loading="lazy"
                title={location.title}
              ></iframe>
              
              <h3>{location.title}</h3>
              {location.parent && <h4 className="subBlockLabel">Inside {location.parent}</h4>}
              <p>{location.description}</p>
            </div>
          ))
        ) : (
          <p className="noResults">No locations found.</p>
        )}
      </section>

      <section className="faqSection">
        <h2>Frequently Asked Questions</h2>
        <div className="faqCard">
          <h3>How do I access the campus tour?</h3>
          <p>You can use the search bar or browse the cards below.</p>
        </div>
        <div className="faqCard">
          <h3>Can I get live navigation?</h3>
          <p>Yes! Click on the map pin to open Google Maps navigation.</p>
        </div>
        <div className="faqCard">
          <h3>Are there event-specific pins?</h3>
          <p>Yes, we highlight ongoing and upcoming events on the map as well.</p>
        </div>
      </section>

      <footer className="tourFooter">
        <p>&copy; 2025 HITEC University. All rights reserved.</p>
        <div className="tourSocialIcons">
          <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
         
          <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
          <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
        </div>
      </footer>
    </>
  );
};

export default Tour;
