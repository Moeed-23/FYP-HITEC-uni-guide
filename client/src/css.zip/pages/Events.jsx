import React from 'react';
import { Link } from 'react-router-dom';
import '../css/events.css'; // Optionally extract the CSS for cleaner JSX
import "@fortawesome/fontawesome-free/css/all.min.css";

const Events = () => {
  return (
    <>
    <title>HITEC | UNIGUIDE | Events</title>
    
    <div className="eventsPage">
      <header className="landing-header">
              {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
              <nav>
                <Link to="/homepage">Home</Link>
                <Link to="/chatbot">Chat</Link>
                <Link to="/admissions">Admissions</Link>
                <Link to="/events">Events</Link>
                <Link to="/tour">Tour</Link>
                <Link to="/dashboard">Dashboard</Link>
                <Link to="/alumni">Alumni</Link>
                <Link to="/industry-integration">Industry Integration</Link>
                <Link to="/feedback">Feedback</Link>
              </nav>
            </header>

      <section className="eventsHero">
        <h1>Upcoming Events</h1>
        <p>
          Stay updated with the latest happenings at HITEC University. Join us in
          making learning an engaging and memorable experience.
        </p>
      </section>

      <section className="eventsSection">
        <h2>Featured Events</h2>

        <div className="eventCard">
          <h3>Annual Science and Technology Fair</h3>
          <p>Date: March 15, 2025</p>
          <p>Location: HITEC University Main Auditorium</p>
          <p>
            Explore innovative projects and ideas presented by our talented students
            and faculty.
          </p>
          <a href="#">Learn More</a>
        </div>

        <div className="eventCard">
          <h3>Career Counseling Workshop</h3>
          <p>Date: April 10, 2025</p>
          <p>Location: Conference Hall B</p>
          <p>
            Join industry experts to get insights and guidance for your future career
            paths.
          </p>
          <a href="#">Register Now</a>
        </div>

        <div className="eventCard">
          <h3>Alumni Networking Night</h3>
          <p>Date: May 5, 2025</p>
          <p>Location: HITEC University Lawn</p>
          <p>
            Reconnect with your batchmates and build meaningful professional
            connections.
          </p>
          <a href="#">RSVP Here</a>
        </div>
      </section>

      <footer className="eventsFooter">
        <p>&copy; 2025 HITEC University. All rights reserved.</p>
        <div className="eventsSocialIcons">
        <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
        
        <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>        </div>
      </footer>
    </div>
    </>
  );
};

export default Events;
