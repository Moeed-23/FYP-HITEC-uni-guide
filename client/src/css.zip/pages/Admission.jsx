import React from "react";
import { Link } from "react-router-dom";
import "../css/admissionpage.css";
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"></link>
import "@fortawesome/fontawesome-free/css/all.min.css";

const Admissions = () => {
  return (
    <>
      <title>HITEC | UNIGUIDE | ADMISSIONS</title>
      <header className="landing-header">
        {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
        <nav>
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <section className="hero_admission">
        <h1>Join the HITEC University Family</h1>
        <p>
          Your journey to success begins here. At HITEC University, we provide
          the tools, resources, and community to help you thrive academically
          and professionally.
        </p>
        <p>
          Our world-class faculty, state-of-the-art facilities, and extensive
          alumni network will empower you to become a leader in your field.
          Join us for the Fall 2025 intake and unlock endless opportunities!
        </p>
        <a
          href="http://111.68.98.206/Default.aspx"
          target="_blank"
          rel="noopener noreferrer"
          className="cta-button_2">
          Apply Now
        </a>
      </section>

      <section className="admissions-section">
        <h2>Admissions Overview</h2>
        <p>
          We offer diverse programs to help you shape your future. With
          excellent faculty, state-of-the-art facilities, and a vibrant campus
          life, HITEC University provides all you need to succeed.
        </p>
        <img
          src="https://cm.hitecuni.edu.pk/_FLS_/2661_Event.JPG"
          alt="University Admissions"
        />

        <div className="requirements">
          <div>
            <h3>Admission Requirements</h3>
            <ul>
              <li>Minimum 60% in HSSC or equivalent for undergraduate programs.</li>
              <li>Minimum 50% for postgraduate admissions.</li>
              <li>Valid NTS/Entry Test Scores for some programs.</li>
              <li>English Proficiency Test (if applicable).</li>
            </ul>
          </div>
          <div>
            <h3>Required Documents</h3>
            <ul>
              <li>Completed Application Form.</li>
              <li>Photocopies of Academic Transcripts & Certificates.</li>
              <li>Valid CNIC or B-Form.</li>
              <li>Passport-sized Photographs (3).</li>
              <li>Proof of Entry Test Scores (if applicable).</li>
            </ul>
          </div>
        </div>

        <div className="process">
          <div>
            <h3>Application Process</h3>
            <p>Follow these simple steps to complete your application:</p>
            <ul>
              <li>Step 1: Fill out the application form on our website.</li>
              <li>Step 2: Upload required documents.</li>
              <li>Step 3: Take the entry test (if applicable).</li>
              <li>Step 4: Wait for confirmation and admission details.</li>
            </ul>
          </div>
          <div>
            <h3>Important Dates</h3>
            <p>Keep track of application deadlines and admission test dates:</p>
            <ul>
              <li>Application Deadline: April 30, 2025.</li>
              <li>Entry Test Date: May 15, 2025.</li>
              <li>Result Announcement: June 1, 2025.</li>
            </ul>
          </div>
        </div>
      </section>

      <section className="features_1">
        <h2>Why Choose HITEC University?</h2>
        <p>
          Discover the benefits of studying at HITEC University, where
          innovation and excellence are at the heart of everything we do.
        </p>
        <a
          href="homepage"
          className="cta-button_2"
        >
          Discover
        </a>
      </section>

      <footer>
        <p>&copy; 2025 HITEC University. All rights reserved.</p>
        <div className="social-icons">
          <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
          <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
          <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
        </div>
      </footer>
    </>
  );
};

export default Admissions;
