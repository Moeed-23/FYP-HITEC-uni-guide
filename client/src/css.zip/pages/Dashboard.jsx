// import React, { useEffect } from 'react';
// import { Link } from "react-router-dom";
// import Chart from 'chart.js/auto';
// import '../css/dashboard.css';
// import "@fortawesome/fontawesome-free/css/all.min.css";

// const Dashboard = () => {
//   useEffect(() => {
//     // User Engagement Bar ChartJS
//     const ctx1 = document.getElementById('engagementChart').getContext('2d');
//     new Chart(ctx1, {
//       type: 'bar',
//       data: {
//         labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
//         datasets: [{
//           label: 'Active Users (%)',
//           data: [80, 75, 90, 85, 92],
//           backgroundColor: '#f77f00',
//           borderColor: '#f77f00',
//           borderWidth: 1
//         }]
//       },
//       options: {
//         responsive: true
//       }
//     });

//     // Response Accuracy Pie ChartJS
//     const ctx2 = document.getElementById('accuracyChart').getContext('2d');
//     new Chart(ctx2, {
//       type: 'pie',
//       data: {
//         labels: ['Correct', 'Incorrect'],
//         datasets: [{
//           label: 'Response Accuracy',
//           data: [85, 15],
//           backgroundColor: ['#2a9d8f', '#e63946']
//         }]
//       },
//       options: {
//         responsive: true
//       }
//     });

//     // User Satisfaction Line ChartJS
//     const ctx3 = document.getElementById('satisfactionChart').getContext('2d');
//     new Chart(ctx3, {
//       type: 'line',
//       data: {
//         labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
//         datasets: [{
//           label: 'User Satisfaction (%)',
//           data: [70, 75, 80, 85, 90],
//           fill: false,
//           borderColor: '#e63946',
//           tension: 0.1
//         }]
//       },
//       options: {
//         responsive: true
//       }
//     });

//     // Total Interactions Radar ChartJS
//     const ctx4 = document.getElementById('interactionsChart').getContext('2d');
//     new Chart(ctx4, {
//       type: 'radar',
//       data: {
//         labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
//         datasets: [{
//           label: 'Interactions',
//           data: [120, 150, 170, 160, 190],
//           backgroundColor: 'rgba(231, 97, 97, 0.5)',
//           borderColor: '#e63946',
//           borderWidth: 1
//         }]
//       },
//       options: {
//         responsive: true
//       }
//     });
//   }, []);

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD</title>
//       <header className="landing-header">
//         {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <section className="heroSection">
//         <h1>Welcome to Your Dashboard</h1>
//         <p>Track your progress, stay updated, and access key features.</p>
//       </section>

//       <section className="dashboardSection">
//         <h2>Your Dashboard</h2>
//         <div className="cardContainer">
//           <div className="dashboardCard">
//             <h3><i className="fas fa-user"></i> My Profile</h3>
//             <p>Update your personal information and preferences.</p>
//           </div>
//           <div className="dashboardCard">
//             <h3><i className="fas fa-save"></i> Saved Questions</h3>
//             <p>Access and manage your saved queries.</p>
//           </div>
//           <div className="dashboardCard">
//             <h3><i className="fas fa-bell"></i> Notifications</h3>
//             <p>Stay updated with important alerts and announcements.</p>
//           </div>
//           <div className="dashboardCard">
//             <h3><i className="fas fa-calendar-alt"></i> Academic Schedule</h3>
//             <p>Keep track of your academic activities and deadlines.</p>
//           </div>
//         </div>
//       </section>

//       <section className="graphContainer">
//         <div className="chartCard">
//           <h3>User Engagement</h3>
//           <canvas id="engagementChart" width="400" height="400"></canvas>
//         </div>
//         <div className="chartCard">
//           <h3>Response Accuracy</h3>
//           <canvas id="accuracyChart" width="400" height="400"></canvas>
//         </div>
//         <div className="chartCard">
//           <h3>User Satisfaction</h3>
//           <canvas id="satisfactionChart" width="400" height="400"></canvas>
//         </div>
//         <div className="chartCard">
//           <h3>Total Interactions</h3>
//           <canvas id="interactionsChart" width="400" height="400"></canvas>
//         </div>
//       </section>

//       <footer className="footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="socialIcons">
//           <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
//           <a href="#"><i className="fab fa-twitter"></i></a>
//           <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
//           <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;



/////////////2


// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import '../css/dashboard.css'; // You can extract styles here

// const Dashboard = () => {
//   const { user } = useAuth();
//   const [userData, setUserData] = useState(null);

//   useEffect(() => {
//     if (user?._id) {
//       const fetchUserData = async () => {
//         try {
//           const apiUrl = import.meta.env.VITE_API_URL;
//           const res = await axios.get(`${apiUrl}/api/User/${user._id}`, {
//             headers: {
//               Authorization: `Bearer ${localStorage.getItem("token")}`,
//             },
//           });
//           setUserData(res.data);
//         } catch (err) {
//           console.error("Error fetching user data:", err);
//         }
//       };
//       fetchUserData();
//     }
//   }, [user]);

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD</title>

//         <header className="landing-header">
//           {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
//           <nav>
//             <Link to="/homepage">Home</Link>
//             <Link to="/chatbot">Chat</Link>
//             <Link to="/admissions">Admissions</Link>
//             <Link to="/events">Events</Link>
//             <Link to="/tour">Tour</Link>
//             <Link to="/dashboard">Dashboard</Link>
//             <Link to="/alumni">Alumni</Link>
//             <Link to="/industry-integration">Industry Integration</Link>
//             <Link to="/feedback">Feedback</Link>
//           </nav>
//         </header>
        
//         <div className="dashboard-wrapper">
//         <h1>Welcome, {userData?.name || "User"}!</h1>
//           <section className="dashboard-hero">
//             <h1>Welcome to Your Dashboard</h1>
//             <p>Track your progress, stay updated, and access key features.</p>
//           </section>

//           <section className="dashboard-main">
//             <h2>Your Dashboard</h2>
//             <div className="dashboard-cards">
//               <div className="dashboard-card">
//                 <h3><i className="fas fa-user"></i> My Profile</h3>
//                 <p>Update your personal information and preferences.</p>
//               </div>
//               <div className="dashboard-card">
//                 <h3><i className="fas fa-save"></i> Saved Questions</h3>
//                 <p>Access and manage your saved queries.</p>
//               </div>
//               <div className="dashboard-card">
//                 <h3><i className="fas fa-bell"></i> Notifications</h3>
//                 <p>Stay updated with important alerts and announcements.</p>
//               </div>
//               <div className="dashboard-card">
//                 <h3><i className="fas fa-calendar-alt"></i> Academic Schedule</h3>
//                 <p>Keep track of your academic activities and deadlines.</p>
//               </div>
//             </div>
//           </section>

//           <section className="dashboard-graphs">
//             <div className="dashboard-graph">
//               <h3>User Engagement</h3>
//               <canvas id="engagementChart" width="400" height="400"></canvas>
//             </div>
//             <div className="dashboard-graph">
//               <h3>Response Accuracy</h3>
//               <canvas id="accuracyChart" width="400" height="400"></canvas>
//             </div>
//             <div className="dashboard-graph">
//               <h3>User Satisfaction</h3>
//               <canvas id="satisfactionChart" width="400" height="400"></canvas>
//             </div>
//             <div className="dashboard-graph">
//               <h3>Total Interactions</h3>
//               <canvas id="interactionsChart" width="400" height="400"></canvas>
//             </div>
//           </section>

//           <footer className="dashboard-footer">
//             <p>&copy; 2025 HITEC University. All rights reserved.</p>
//             <div className="dashboard-social-icons">
//               <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
//               <a href="#"><i className="fab fa-twitter"></i></a>
//               <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
//               <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
//             </div>
//           </footer>
//         </div>
       
//       </>
//       );
// };

// export default Dashboard;










////////////////////////







// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../css/dashboard.css";

// const Dashboard = () => {
//   const { user } = useAuth();
//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   useEffect(() => {
//     document.title = "HITEC | UNIGUIDE | DASHBOARD";
//   }, []);

//   useEffect(() => {
//     const fetchUserData = async () => {
//       if (!user?._id) {
//         setLoading(false); // << Add this!
//         return;
//       }
  
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         const response = await axios.get(`${apiUrl}/api/User/${user._id}`, {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem("token")}`,
//           },
//         });
//         setUserData(response.data);
//       } catch (err) {
//         setError("Failed to load user data. Please try again later.");
//         console.error("Error fetching user data:", err);
//       } finally {
//         setLoading(false);
//       }
//     };
  
//     fetchUserData();
//   }, [user]);
  

//   return (
//     <>
//       <header className="landing-header">
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <main className="dashboard-wrapper">
//         {loading ? (
//           <div className="dashboard-loading">
//             <i className="fas fa-spinner fa-spin"></i>
//             <span>Loading your dashboard...</span>
//           </div>
//         ) : error ? (
//           <div className="dashboard-error" role="alert">
//             <i className="fas fa-exclamation-triangle"></i>
//             <span>{error}</span>
//           </div>
//         ) : (
//           <>
//             <h1>Welcome, {userData?.name || "User"}!</h1>

//             <section className="dashboard-hero">
//               <h1>Welcome to Your Dashboard</h1>
//               <p>Track your progress, stay updated, and access key features.</p>
//             </section>

//             <section className="dashboard-main">
//               <h2>Your Dashboard</h2>
//               <div className="dashboard-cards">
//                 <div className="dashboard-card">
//                   <h3><i className="fas fa-user"></i> My Profile</h3>
//                   <p>Update your personal information and preferences.</p>
//                 </div>
//                 <div className="dashboard-card">
//                   <h3><i className="fas fa-save"></i> Saved Questions</h3>
//                   <p>Access and manage your saved queries.</p>
//                 </div>
//                 <div className="dashboard-card">
//                   <h3><i className="fas fa-bell"></i> Notifications</h3>
//                   <p>Stay updated with important alerts and announcements.</p>
//                 </div>
//                 <div className="dashboard-card">
//                   <h3><i className="fas fa-calendar-alt"></i> Academic Schedule</h3>
//                   <p>Keep track of your academic activities and deadlines.</p>
//                 </div>
//               </div>
//             </section>

//             <section className="dashboard-graphs">
//               <div className="dashboard-graph">
//                 <h3>User Engagement</h3>
//                 <canvas id="engagementChart" width="400" height="400"></canvas>
//               </div>
//               <div className="dashboard-graph">
//                 <h3>Response Accuracy</h3>
//                 <canvas id="accuracyChart" width="400" height="400"></canvas>
//               </div>
//               <div className="dashboard-graph">
//                 <h3>User Satisfaction</h3>
//                 <canvas id="satisfactionChart" width="400" height="400"></canvas>
//               </div>
//               <div className="dashboard-graph">
//                 <h3>Total Interactions</h3>
//                 <canvas id="interactionsChart" width="400" height="400"></canvas>
//               </div>
//             </section>
//           </>
//         )}
//       </main>

//       <footer className="dashboard-footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="dashboard-social-icons">
//           <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//             <i className="fab fa-facebook-f"></i>
//           </a>
//           <a href="#" aria-label="Twitter">
//             <i className="fab fa-twitter"></i>
//           </a>
//           <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
//             <i className="fab fa-instagram"></i>
//           </a>
//           <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all" aria-label="LinkedIn">
//             <i className="fab fa-linkedin-in"></i>
//           </a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;










///////////////////





// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../css/dashboard.css";

// const Dashboard = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();
//   const [userData, setUserData] = useState(null);
//   const [setLoading] = useState(true);
//   const [setError] = useState("");
// useEffect(() => {
//   const fetchUserData = async () => {
//     const token = localStorage.getItem("token");

//     // Log the user data and token
//     console.log("user:", user);
//     console.log("token:", token);

//     if (!user?._id || !token) {
//       setLoading(false);
//       navigate("/login"); // Optional: redirect to login
//       return;
//     }

//     try {
//       const apiUrl = import.meta.env.VITE_API_URL;
//       const response = await axios.get(`${apiUrl}/api/User/${user._id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });
//       setUserData(response.data);
//     } catch (err) {
//       console.error("Error fetching user data:", err);
//       setError("Failed to load user data. Please try again later.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   fetchUserData();
// }, [user, navigate]);


//   return (
//     <>
//     <title>HITEC | UNIGUIDE | DASHBOARD</title>
//       <header className="landing-header">
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <main className="dashboard-wrapper">
//         <h1>Welcome, {userData?.name || "User"}!</h1>

//         <section className="dashboard-hero">
//           <h1>Welcome to Your Dashboard</h1>
//           <p>Track your progress, stay updated, and access key features.</p>
//         </section>

//         <section className="dashboard-main">
//           <h2>Your Dashboard</h2>
//           <div className="dashboard-cards">
//             <div className="dashboard-card">
//               <h3><i className="fas fa-user"></i> My Profile</h3>
//               <p>Update your personal information and preferences.</p>
//             </div>
//             <div className="dashboard-card">
//               <h3><i className="fas fa-save"></i> Saved Questions</h3>
//               <p>Access and manage your saved queries.</p>
//             </div>
//             <div className="dashboard-card">
//               <h3><i className="fas fa-bell"></i> Notifications</h3>
//               <p>Stay updated with important alerts and announcements.</p>
//             </div>
//             <div className="dashboard-card">
//               <h3><i className="fas fa-calendar-alt"></i> Academic Schedule</h3>
//               <p>Keep track of your academic activities and deadlines.</p>
//             </div>
//           </div>
//         </section>

//         <section className="dashboard-graphs">
//           {["Engagement", "Accuracy", "Satisfaction", "Interactions"].map((label) => (
//             <div className="dashboard-graph" key={label}>
//               <h3>User {label}</h3>
//               <canvas id={`${label.toLowerCase()}Chart`} width="400" height="400"></canvas>
//             </div>
//           ))}
//         </section>
//       </main>

//       <footer className="dashboard-footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="dashboard-social-icons">
//           <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//             <i className="fab fa-facebook-f"></i>
//           </a>
          
//           <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
//             <i className="fab fa-instagram"></i>
//           </a>
//           <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all" aria-label="LinkedIn">
//             <i className="fab fa-linkedin-in"></i>
//           </a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;



/////////////////////
////////////////
///////


// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../css/dashboard.css";

// const Dashboard = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   const [userData, setUserData] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   useEffect(() => {
//     const fetchUserData = async () => {
//       const token = localStorage.getItem("token");
  
//       // Check if user exists and if the token is available
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
  
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL; // e.g. http://localhost:2500
//         const response = await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setUserData(response.data);
//       } catch (err) {
//         console.error("Error fetching user data:", err);
//         setError("Failed to load user data. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };
  
//     fetchUserData();
//   }, [user, navigate]);
  
//   if (loading) return <div>Loading your dashboard...</div>;
//   if (error) return <div>{error}</div>;

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD</title>
//       <header className="landing-header">
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <main className="dashboard-wrapper">
//         <h1>Welcome, {userData?.name || "User"}!</h1>

//         <section className="dashboard-hero">
//           <h1>Welcome to Your Dashboard</h1>
//           <p>Track your progress, stay updated, and access key features.</p>
//         </section>

//         <section className="dashboard-main">
//           <h2>Your Dashboard</h2>
//           <div className="dashboard-cards">
//             <div className="dashboard-card">
//               <Link to="/profile">
//                 <h3>
//                   <i className="fas fa-user"></i> My Profile
//                 </h3>
//                 <p>Update your personal information and preferences.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/saved-questions">
//                 <h3>
//                   <i className="fas fa-save"></i> Saved Questions
//                 </h3>
//                 <p>Access and manage your saved queries.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/notifications">
//                 <h3>
//                   <i className="fas fa-bell"></i> Notifications
//                 </h3>
//                 <p>Stay updated with important alerts and announcements.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/academic-schedule">
//                 <h3>
//                   <i className="fas fa-calendar-alt"></i> Academic Schedule
//                 </h3>
//                 <p>Keep track of your academic activities and deadlines.</p>
//               </Link>
//             </div>
//           </div>
//         </section>

//         <section className="dashboard-graphs">
//           {["Engagement", "Accuracy", "Satisfaction", "Interactions"].map(label => (
//             <div className="dashboard-graph" key={label}>
//               <h3>User {label}</h3>
//               <canvas
//                 id={`${label.toLowerCase()}Chart`}
//                 width="400"
//                 height="400"
//               ></canvas>
//             </div>
//           ))}
//         </section>
//       </main>

//       <footer className="dashboard-footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="dashboard-social-icons">
//           <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//             <i className="fab fa-facebook-f"></i>
//           </a>
//           <a
//             href="https://www.instagram.com/hitecuni/?hl=en"
//             aria-label="Instagram"
//           >
//             <i className="fab fa-instagram"></i>
//           </a>
//           <a
//             href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"
//             aria-label="LinkedIn"
//           >
//             <i className="fab fa-linkedin-in"></i>
//           </a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;



//////////////////////
/////////////


// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../css/dashboard.css";

// const Dashboard = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   // Remove userData since it's not used
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   // If you still want to verify the user by fetching data, you can use a dummy variable
//   useEffect(() => {
//     const verifyUser = async () => {
//       const token = localStorage.getItem("token");

//       // Check if user exists and if the token is available
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }

//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         // We are fetching the user data for verification only
//         await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//       } catch (err) {
//         console.error("Error verifying user data:", err);
//         setError("Failed to load user data. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     verifyUser();
//   }, [user, navigate]);

//   if (loading) return <div>Loading your dashboard...</div>;
//   if (error) return <div>{error}</div>;


//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD</title>
//       <header className="landing-header">
//         <nav>
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <main className="dashboard-wrapper">
//         <section className="dashboard-hero">
//           <h1>Welcome to Your Dashboard</h1>
//           <p>Track your progress, stay updated, and access key features.</p>
//         </section>

//         <section className="dashboard-main">
//           <h2>Your Dashboard</h2>
//           <div className="dashboard-cards">
//             <div className="dashboard-card">
//               <Link to="/profile">
//                 <h3>
//                   <i className="fas fa-user"></i> My Profile
//                 </h3>
//                 <p>Update your personal information and preferences.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/saved-questions">
//                 <h3>
//                   <i className="fas fa-save"></i> Saved Questions
//                 </h3>
//                 <p>Access and manage your saved queries.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/notifications">
//                 <h3>
//                   <i className="fas fa-bell"></i> Notifications
//                 </h3>
//                 <p>Stay updated with important alerts and announcements.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/academic-schedule">
//                 <h3>
//                   <i className="fas fa-calendar-alt"></i> Academic Schedule
//                 </h3>
//                 <p>Keep track of your academic activities and deadlines.</p>
//               </Link>
//             </div>
//           </div>
//         </section>

//         <section className="dashboard-graphs">
//           {["Engagement", "Accuracy", "Satisfaction", "Interactions"].map(label => (
//             <div className="dashboard-graph" key={label}>
//               <h3>User {label}</h3>
//               <canvas id={`${label.toLowerCase()}Chart`} width="400" height="400"></canvas>
//             </div>
//           ))}
//         </section>
//       </main>

//       <footer className="dashboard-footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="dashboard-social-icons">
//           <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//             <i className="fab fa-facebook-f"></i>
//           </a>
//           <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
//             <i className="fab fa-instagram"></i>
//           </a>
//           <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all" aria-label="LinkedIn">
//             <i className="fab fa-linkedin-in"></i>
//           </a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;



////////////////////
/////////
//////

// import { useAuth } from "../context/AuthContext";
// import axios from "axios";
// import { useState, useEffect } from "react";
// import { Link, useNavigate } from "react-router-dom";
// import Chart from "chart.js/auto"; // Import Chart.js for graphs
// import "@fortawesome/fontawesome-free/css/all.min.css";
// import "../css/dashboard.css";

// const Dashboard = () => {
//   const { user } = useAuth();
//   const navigate = useNavigate();

//   // States for loading and error verification
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState("");

//   // Verify user existence on component mount (no userData state)
//   useEffect(() => {
//     const verifyUser = async () => {
//       const token = localStorage.getItem("token");
//       if (!user?._id || !token) {
//         navigate("/login");
//         return;
//       }
//       try {
//         const apiUrl = import.meta.env.VITE_API_URL;
//         // Fetching user data solely for verification purposes.
//         await axios.get(`${apiUrl}/api/users/${user._id}`, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//       } catch (err) {
//         console.error("Error verifying user data:", err);
//         setError("Failed to load user data. Please try again later.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     verifyUser();
//   }, [user, navigate]);

//   // Initialize Charts when not loading
//   useEffect(() => {
//     if (!loading) {
//       // Engagement Chart (Bar)
//       const ctx1 = document.getElementById("engagementchart")?.getContext("2d");
//       if (ctx1) {
//         new Chart(ctx1, {
//           type: "bar",
//           data: {
//             labels: ["Jan", "Feb", "Mar", "Apr", "May"],
//             datasets: [
//               {
//                 label: "Active Users (%)",
//                 data: [80, 75, 90, 85, 92], // Dummy Data
//                 backgroundColor: "rgba(247, 119, 0, 0.2)",
//                 borderColor: "rgba(247, 119, 0, 1)",
//                 borderWidth: 1,
//               },
//             ],
//           },
//           options: {
//             responsive: true,
//             maintainAspectRatio: false,
//           },
//         });
//       }
//       // Accuracy Chart (Pie)
//       const ctx2 = document.getElementById("accuracychart")?.getContext("2d");
//       if (ctx2) {
//         new Chart(ctx2, {
//           type: "pie",
//           data: {
//             labels: ["Correct", "Incorrect"],
//             datasets: [
//               {
//                 label: "Response Accuracy",
//                 data: [85, 15], // Dummy Data
//                 backgroundColor: ["#2a9d8f", "#e63946"],
//               },
//             ],
//           },
//           options: {
//             responsive: true,
//             maintainAspectRatio: false,
//           },
//         });
//       }
//       // Satisfaction Chart (Line)
//       const ctx3 = document.getElementById("satisfactionchart")?.getContext("2d");
//       if (ctx3) {
//         new Chart(ctx3, {
//           type: "line",
//           data: {
//             labels: ["Jan", "Feb", "Mar", "Apr", "May"],
//             datasets: [
//               {
//                 label: "User Satisfaction (%)",
//                 data: [70, 75, 80, 85, 90], // Dummy Data
//                 fill: false,
//                 borderColor: "#e63946",
//                 tension: 0.1,
//               },
//             ],
//           },
//           options: {
//             responsive: true,
//             maintainAspectRatio: false,
//           },
//         });
//       }
//       // Interactions Chart (Radar)
//       const ctx4 = document.getElementById("interactionschart")?.getContext("2d");
//       if (ctx4) {
//         new Chart(ctx4, {
//           type: "radar",
//           data: {
//             labels: ["Jan", "Feb", "Mar", "Apr", "May"],
//             datasets: [
//               {
//                 label: "Total Interactions",
//                 data: [120, 150, 170, 160, 190], // Dummy Data
//                 backgroundColor: "rgba(231, 97, 97, 0.5)",
//                 borderColor: "#e63946",
//                 borderWidth: 1,
//               },
//             ],
//           },
//           options: {
//             responsive: true,
//             maintainAspectRatio: false,
//           },
//         });
//       }
//     }
//   }, [loading]);

//   if (loading) return <div>Loading your dashboard...</div>;
//   if (error) return <div>{error}</div>;

//   return (
//     <>
//       <title>HITEC | UNIGUIDE | DASHBOARD</title>
//       <header className="landing-header">
//         <nav className="dashboard-nav">
//           <Link to="/homepage">Home</Link>
//           <Link to="/chatbot">Chat</Link>
//           <Link to="/admissions">Admissions</Link>
//           <Link to="/events">Events</Link>
//           <Link to="/tour">Tour</Link>
//           <Link to="/dashboard">Dashboard</Link>
//           <Link to="/alumni">Alumni</Link>
//           <Link to="/industry-integration">Industry Integration</Link>
//           <Link to="/feedback">Feedback</Link>
//         </nav>
//       </header>

//       <main className="dashboard-wrapper">
//         <section className="dashboard-hero">
//           <h1>Welcome to Your Dashboard</h1>
//           <p>Track your progress, stay updated, and access key features.</p>
//         </section>

//         <section className="dashboard-main">
//           <h2>Your Dashboard</h2>
//           <div className="dashboard-cards">
//             <div className="dashboard-card">
//               <Link to="/profile">
//                 <h3>
//                   <i className="fas fa-user"></i> My Profile
//                 </h3>
//                 <p>Update your personal information and preferences.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/saved-questions">
//                 <h3>
//                   <i className="fas fa-save"></i> Saved Questions
//                 </h3>
//                 <p>Access and manage your saved queries.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/notifications">
//                 <h3>
//                   <i className="fas fa-bell"></i> Notifications
//                 </h3>
//                 <p>Stay updated with important alerts and announcements.</p>
//               </Link>
//             </div>
//             <div className="dashboard-card">
//               <Link to="/academic-schedule">
//                 <h3>
//                   <i className="fas fa-calendar-alt"></i> Academic Schedule
//                 </h3>
//                 <p>Keep track of your academic activities and deadlines.</p>
//               </Link>
//             </div>
//           </div>
//         </section>

//         <section className="dashboard-graphs">
//           <div className="dashboard-graph">
//             <h3>User Engagement</h3>
//             <canvas id="engagementchart"></canvas>
//           </div>
//           <div className="dashboard-graph">
//             <h3>Response Accuracy</h3>
//             <canvas id="accuracychart"></canvas>
//           </div>
//           <div className="dashboard-graph">
//             <h3>User Satisfaction</h3>
//             <canvas id="satisfactionchart"></canvas>
//           </div>
//           <div className="dashboard-graph">
//             <h3>Total Interactions</h3>
//             <canvas id="interactionschart"></canvas>
//           </div>
//         </section>
//       </main>

//       <footer className="dashboard-footer">
//         <p>&copy; 2025 HITEC University. All rights reserved.</p>
//         <div className="dashboard-social-icons">
//           <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
//             <i className="fab fa-facebook-f"></i>
//           </a>
//           <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
//             <i className="fab fa-instagram"></i>
//           </a>
//           <a
//             href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"
//             aria-label="LinkedIn"
//           >
//             <i className="fab fa-linkedin-in"></i>
//           </a>
//         </div>
//       </footer>
//     </>
//   );
// };

// export default Dashboard;




////////////////////////




import { useAuth } from "../context/AuthContext";
import axios from "axios";
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import Chart from "chart.js/auto";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "../css/dashboard.css";

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState("");

  // First, verify we actually have a user + token
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!user?._id || !token) {
      return navigate("/login", { replace: true });
    }

    // Optionally verify via API
    (async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        await axios.get(`${apiUrl}/api/users/${user._id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
      } catch (e) {
        console.error("Session invalid:", e);
        setError("Session expired. Redirecting to login…");
        return setTimeout(() => navigate("/login", { replace: true }), 2000);
      } finally {
        setLoading(false);
      }
    })();
  }, [user, navigate]);

  // Once verified, spin up charts
  useEffect(() => {
    if (loading || error) return;

    const init = (id, cfg) => {
      const ctx = document.getElementById(id)?.getContext("2d");
      if (ctx) new Chart(ctx, cfg);
    };

    init("engagementchart", {
      type: "bar",
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May"],
        datasets: [{ 
          label: "Active Users (%)",
          data: [80,75,90,85,92],
          backgroundColor: "rgba(247,119,0,0.2)",
          borderColor: "rgba(247,119,0,1)",
          borderWidth: 1
        }]
      },
      options: { responsive:true, maintainAspectRatio:false }
    });

    init("accuracychart", {
      type: "pie",
      data: {
        labels: ["Correct","Incorrect"],
        datasets: [{ data:[85,15], backgroundColor:["#2a9d8f","#e63946"] }]
      },
      options: { responsive:true, maintainAspectRatio:false }
    });

    init("satisfactionchart", {
      type: "line",
      data: {
        labels: ["Jan","Feb","Mar","Apr","May"],
        datasets: [{ 
          label: "User Satisfaction (%)",
          data: [70,75,80,85,90],
          fill:false,
          borderColor:"#e63946",
          tension:0.1
        }]
      },
      options: { responsive:true, maintainAspectRatio:false }
    });

    init("interactionschart", {
      type: "radar",
      data: {
        labels: ["Jan","Feb","Mar","Apr","May"],
        datasets: [{ 
          label: "Total Interactions",
          data: [120,150,170,160,190],
          backgroundColor:"rgba(231,97,97,0.5)",
          borderColor:"#e63946",
          borderWidth:1
        }]
      },
      options: { responsive:true, maintainAspectRatio:false }
    });

  }, [loading, error]);

  if (loading) return <div className="p-4 text-center">Loading your dashboard…</div>;
  if (error)   return <div className="p-4 text-center text-red-500">{error}</div>;

  return (
    <>
      <title>HITEC | UNIGUIDE | DASHBOARD</title>
      <header className="landing-header">
        <nav className="dashboard-nav">
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <main className="dashboard-wrapper">
        <section className="dashboard-hero">
          <h1>Welcome to Your Dashboard</h1>
          <p>Track your progress, stay updated, and access key features.</p>
        </section>

        <section className="dashboard-main">
          <h2>Your Dashboard</h2>
          <div className="dashboard-cards">
            <div className="dashboard-card">
              <Link to="/profile">
                <h3>
                  <i className="fas fa-user"></i> My Profile
                </h3>
                <p>Update your personal information and preferences.</p>
              </Link>
            </div>
            <div className="dashboard-card">
              <Link to="/saved-questions">
                <h3>
                  <i className="fas fa-save"></i> Saved Questions
                </h3>
                <p>Access and manage your saved queries.</p>
              </Link>
            </div>
            <div className="dashboard-card">
              <Link to="/notifications">
                <h3>
                  <i className="fas fa-bell"></i> Notifications
                </h3>
                <p>Stay updated with important alerts and announcements.</p>
              </Link>
            </div>
            <div className="dashboard-card">
              <Link to="/academic-schedule">
                <h3>
                  <i className="fas fa-calendar-alt"></i> Academic Schedule
                </h3>
                <p>Keep track of your academic activities and deadlines.</p>
              </Link>
            </div>
          </div>
        </section>

        <section className="dashboard-graphs">
          <div className="dashboard-graph">
            <h3>User Engagement</h3>
            <canvas id="engagementchart"></canvas>
          </div>
          <div className="dashboard-graph">
            <h3>Response Accuracy</h3>
            <canvas id="accuracychart"></canvas>
          </div>
          <div className="dashboard-graph">
            <h3>User Satisfaction</h3>
            <canvas id="satisfactionchart"></canvas>
          </div>
          <div className="dashboard-graph">
            <h3>Total Interactions</h3>
            <canvas id="interactionschart"></canvas>
          </div>
        </section>
      </main>

      <footer className="dashboard-footer">
        <p>&copy; 2025 HITEC University. All rights reserved.</p>
        <div className="dashboard-social-icons">
          <a href="https://www.facebook.com/hitecuni/" aria-label="Facebook">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="https://www.instagram.com/hitecuni/?hl=en" aria-label="Instagram">
            <i className="fab fa-instagram"></i>
          </a>
          <a
            href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"
            aria-label="LinkedIn"
          >
            <i className="fab fa-linkedin-in"></i>
          </a>
        </div>
      </footer>
    </>
  );
};
