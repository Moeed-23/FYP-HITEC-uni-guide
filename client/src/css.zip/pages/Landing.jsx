import React from "react";
import { Link } from "react-router-dom";
import "../css/Landing.css"; 
import "@fortawesome/fontawesome-free/css/all.min.css";

const Landing = () => {
  return (
    <>
    <title>HITEC | UNIGUIDE</title>
    
      <header className="landing-header">
        <nav>
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>

      <section className="hero">
        <div className="text-section">
          <h1>Your AI University Assistant</h1>
          <p>
          Your one-stop solution for university-related assistance. 
          Whether you need help with admissions, events, or campus navigation, 
          our chatbot is here to guide you every step of the way. Discover tailored insights, 
          upcoming events, and explore campuses like never before with our interactive tools and real-time 
          assistance.
          </p>
          <Link to="/features" className="cta-button_1">
            Get Started
          </Link>
        </div>
        <div className="image-section">
          <img
            src="https://botnation.ai/site/wp-content/uploads/2024/01/chatbot-leads.webp"
            alt="Chatbot Illustration"
          />
        </div>
      </section>

      <section className="auth-section">
        <h2>Join the HITEC UNIGUIDE Community</h2>
        <p>
          Sign up to access personalized features or log in if you already have
          an account. Start your journey today!
        </p>
        <div className="auth-buttons">
          <Link to="/signup" className="auth-button">
            Sign Up
          </Link>
          <Link to="/login" className="auth-button">
            Login
          </Link>
        </div>
      </section>

      <footer>
      <p>&copy; 2025 HITEC University. All rights reserved.</p>
      <div className="social-icons">
        <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
        
        <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
      </div>
      </footer>
      
    </>
  );
};

export default Landing;
