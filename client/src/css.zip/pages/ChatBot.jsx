import React from "react";
import { useState } from "react";
import { Link } from "react-router-dom";
import "../css/chatbot.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

const Chat = () => {
    const [messages, setMessages] = useState([
        { text: "Hi! I'm UniGuide. How can I assist you today?", type: "bot" },
        { text: "Can you help me with the admission process?", type: "user" },
        { text: "Sure! What specific information are you looking for?", type: "bot" }
    ]);
    const [input, setInput] = useState("");
    const [typing, setTyping] = useState(false);

    const handleSend = () => {
        if (input.trim() === "") return;

        const userMessage = { text: input, type: "user" };
        setMessages([...messages, userMessage]);
        setInput("");

        setTyping(true);
        setTimeout(() => {
            setTyping(false);
            const botResponse = { text: `You said: "${input}". How else can I assist?`, type: "bot" };
            setMessages((prevMessages) => [...prevMessages, botResponse]);
        }, 1500);
    };

    return (
        <>
            <title>HITEC | UNIGUIDE | CHATBOT</title>
            <header className="landing-header">
                {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
                <nav>
                    <Link to="/homepage">Home</Link>
                    <Link to="/chatbot">Chat</Link>
                    <Link to="/admissions">Admissions</Link>
                    <Link to="/events">Events</Link>
                    <Link to="/tour">Tour</Link>
                    <Link to="/dashboard">Dashboard</Link>
                    <Link to="/alumni">Alumni</Link>
                    <Link to="/industry-integration">Industry Integration</Link>
                    <Link to="/feedback">Feedback</Link>
                </nav>
            </header>

            <div className="chat-container">
                <div className="chat-header">
                    <i className="fas fa-robot"></i> UniGuide Assistant
                </div>

                <div className="chat-messages">
                    {messages.map((msg, index) => (
                        <div key={index} className={`message ${msg.type}-message`}>
                            {msg.text}
                        </div>
                    ))}
                </div>

                {typing && <div className="typing-indicator">UniGuide Assistant is typing...</div>}

                <div className="chat-input">
                    <input
                        type="text"
                        placeholder="Type your message here..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === "Enter") {
                                handleSend();
                            }
                        }}
                    />
                    <button onClick={handleSend}><i className="fas fa-paper-plane"></i></button>
                </div>
            </div>

            <footer>
                <p>&copy; 2025 HITEC University. All rights reserved.</p>
                <div className="social-icons">
                    <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
                    
                    <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
                </div>
            </footer>
        </>
    );
};

export default Chat;
