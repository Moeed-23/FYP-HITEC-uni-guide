import React from "react";
import { Link } from "react-router-dom";
import "../css/alumni.css";
import "@fortawesome/fontawesome-free/css/all.min.css"; // Assuming you will move your CSS to a separate file for this component

const Alumni = () => {
  return (
    <>
    <title>HITEC | UNIGUIDE | ALUMNI</title>
    <div>
      <header className="landing-header">
        {/* <h1><a href="landing-page.html" className="brand-link">HITEC UniGude ChatBot</a></h1> */}
        <nav>
          <Link to="/homepage">Home</Link>
          <Link to="/chatbot">Chat</Link>
          <Link to="/admissions">Admissions</Link>
          <Link to="/events">Events</Link>
          <Link to="/tour">Tour</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/alumni">Alumni</Link>
          <Link to="/industry-integration">Industry Integration</Link>
          <Link to="/feedback">Feedback</Link>
        </nav>
      </header>
      <section className="landing-hero">
        <h1 className="hero-title">Student and Alumni Networking</h1>
        <p className="hero-description">Connecting students with alumni for mentorship, collaboration, and opportunities.</p>
        <a href="#join" className="cta-button">Join the Network</a>
      </section>

      <section className="landing-section" id="features">
        <h2 className="section-title">Why Network with Alumni?</h2>
        <div className="feature-cards">
          <div className="feature-card">
            <h3 className="feature-card-title">Mentorship Opportunities</h3>
            <p className="feature-card-description">Get valuable advice and guidance on career development from experienced alumni.</p>
          </div>
          <div className="feature-card">
            <h3 className="feature-card-title">Collaboration on Projects</h3>
            <p className="feature-card-description">Work together on exciting projects with alumni from diverse fields.</p>
          </div>
          <div className="feature-card">
            <h3 className="feature-card-title">Networking for Job Opportunities</h3>
            <p className="feature-card-description">Build your professional network and find job openings through alumni connections.</p>
          </div>
        </div>
      </section>

      <section className="landing-section" id="alumni">
        <h2 className="section-title">Meet Our Alumni</h2>
        <p className="section-description">Our alumni are not just successful professionals; they are mentors, collaborators, and a valuable part of the Uniguide community. Here are a few of our distinguished alumni who are helping shape the future of various industries:</p>

        <div className="alumni-cards">
          <div className="alumni-card">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQca6sAq-Xpg5Dw2oeALjVYQIfLP7l7JLpqbw&s" alt="John Doe" className="alumni-photo" />
            <h3 className="alumni-name">M.Ahmad</h3>
            <p className="alumni-job-title">Software Engineer at TechCorp</p>
            <p className="alumni-description">John has over 10 years of experience in software engineering and currently leads a team at TechCorp, where they build innovative solutions to improve technology infrastructure.</p>
          </div>
          <div className="alumni-card">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVMmnITUcvL9I9uyLwaWzttwUBNo2UxLQCcw&s" alt="Hira Khan" className="alumni-photo" />
            <h3 className="alumni-name">Hira Khan</h3>
            <p className="alumni-job-title">Data Scientist at DataWave</p>
            <p className="alumni-description">Hira specializes in machine learning and big data analytics. As a data scientist at DataWave, she helps businesses make data-driven decisions.</p>
          </div>
          <div className="alumni-card">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlnapa_okcX2WDOh-ypMm_1YPY1WKMeYXv-LPx3-RaJJd8I7kLg5bCyYpriE412J7hFlY&usqp=CAU" alt="Amna Tahir" className="alumni-photo" />
            <h3 className="alumni-name">Amna Tahir</h3>
            <p className="alumni-job-title">Product Manager at InnovateX</p>
            <p className="alumni-description">Amna Tahir is a seasoned product manager at InnovateX, where she drives product development from ideation to launch.</p>
          </div>
        </div>
      </section>

      <section className="landing-section" id="join">
        <h2 className="section-title">Ready to Join?</h2>
        <p className="section-description">Become a part of our growing community of students and alumni. Networking is the key to unlocking opportunities, and we want you to connect with the right people who can help you achieve your goals.</p>
        <br />
        <a href="/signup" className="cta-button cta-signup">Sign Up Now</a>
      </section>

      <footer className="landing-footer">
        <p>&copy; 2025 HITEC University. All rights reserved.</p>
        <div className="social-icons">
        <a href="https://www.facebook.com/hitecuni/"><i className="fab fa-facebook-f"></i></a>
        
        <a href="https://www.instagram.com/hitecuni/?hl=en"><i className="fab fa-instagram"></i></a>
        <a href="https://www.linkedin.com/school/hitec-university/posts/?feedView=all"><i className="fab fa-linkedin-in"></i></a>
        </div>
      </footer>
    </div>
    </>
  );
};

export default Alumni;
